import serial
import time
import RPi.GPIO as GPIO

import moterdriver
import distance 
import comm

import lcddriver
from time import *
 

GPIO.setwarnings(False)
mode=GPIO.BCM
md=moterdriver.MoterDriver(mode)
ds=distance.Distance(mode)
colider=3
rcMessage=""
toSendMessage=""
port= serial.Serial("/dev/rfcomm0",baudrate=9600)
lcd = lcddriver.lcd()


while True:
    #Moving Car to Foward Direction 
    md.forward()
    
    #getting message from bluetooth
    rcMessage=port.readline()
    if rcv:
        print (rcv)
    
    #Getting distance from this ulterasonic sensor 
    myDistance=ds.getDistance()
    if myDistance==colider:
       
        md.stop()
        
    if myDistance==colider and rcMessage==comm.acidentAlert :
        md.stop
        #code to display message
        
    #if the car stop can move left to over take     
    if myDistance!=colider and rcMessage==comm.overTakeLeft:
        md.left()
        toSendMessage=comm.overTakeLeft
        port.write(str().encode(toSendMessage))
    
        
    
    
    if False :   #condtion if the acident happens to send to other 
        toSendMessage=comm.acidentAlert
        port.write(str().encode(toSendMessage))
    
    time.sleep(3)    