class Comm:
    overTakeLeft="LEFT OVERTAKE"
    overTakeRIGHT="RIGHT OVERTAKE"
    acidentAlert="ALERT : Acident"