class GpioWire:
    TRIG = 4                                 #Associate pin 23 to TRIG
    ECHO = 17                                 #Associate pin 24 to ECHO
    #Resberry pi pin            Moter Controler pin
    M1=6                    #1
    M2=13                   #2
    M3=19                   #3
    M4=26                   #4
   