import serial
import RPi.GPIO as GPIO
import time

ser=serial.Serial("/dev/ttyACM0",9600)  #change ACM number as found from ls /dev/tty/ACM*
ser.baudrate=9600

GPIO.setmode(GPIO.BOARD)


while True:

    read_ser=ser.readline()
    read_ser=str(read_ser)
    
    read_ser=read_ser.replace("b'","")
    read_ser=list(read_ser)
    try :
       
        read_ser.remove('\\')
        read_ser.remove('r')
        read_ser.remove('\\')
        read_ser.remove('n')
        read_ser.remove('\'')
    except:
        print("An exception")
    
    strin=list("1234567890")
    
    
    if read_ser==strin:
        print("okay")
    
    ser.write(bytes("world","utf-8") )
    print(read_ser)
    time.sleep(2)    