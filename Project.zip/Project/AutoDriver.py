import RPi.GPIO as GPIO

import moterdriver
import distance 

GPIO.setwarnings(False)
mode=GPIO.BCM
md=moterdriver.MoterDriver(mode)
ds=distance.Distance(mode)
