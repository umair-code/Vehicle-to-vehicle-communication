import serial
import time
import RPi.GPIO as GPIO
import lcddriver
import serial
import moterdriver
import distance 
import comm
GPIO.setwarnings(False)

ser=serial.Serial("/dev/ttyACM0",9600)  #change ACM number as found from ls /dev/tty/ACM*
ser.baudrate=9600


GPIO.cleanup()
mode=GPIO.BCM
md=moterdriver.MoterDriver(mode)
ds=distance.Distance(mode)
colider=30
rcMessage=""
toSendMessage=""
lcd = lcddriver.lcd()
GPIO.setup(23,GPIO.OUT,initial=GPIO.LOW)
while True:
    #mode=GPIO.BCM
    
 
  
    
    read_ser=ser.readline(ser.inWaiting())
    read_ser=str(read_ser)
    
    read_ser=read_ser.replace("b'","")
    read_ser=list(read_ser)
    try :
       
        read_ser.remove('\\')
        read_ser.remove('r')
        read_ser.remove('\\')
        read_ser.remove('n')
        read_ser.remove('\'')
    except:
        print("An exception")
    
   
    
    
    if read_ser==list("SL"):
        lcd.lcd_clear()
        lcd.lcd_display_string("KEEP IN", 1)
        lcd.lcd_display_string("YOUR LANE", 2)
        GPIO.output(23,GPIO.HIGH)
    elif read_ser==list("AC"):
        lcd.lcd_clear()
        lcd.lcd_display_string("ACCIDENT", 1)
        lcd.lcd_display_string("ON ROAD", 2)
        
    elif read_ser==list("TF"):
        lcd.lcd_clear()
        lcd.lcd_display_string("TRAFFIC", 1)
        lcd.lcd_display_string("SIGNEL", 2)
        
    else :
        
        GPIO.output(23,GPIO.LOW)
    ser.write(bytes("world","utf-8") )
    print(read_ser)

    #Getting distance from this ultrasonic sensor 
    myDistance=ds.getDistance()
    print(myDistance)
    if myDistance<colider or read_ser == list("AC") or read_ser == list("TF") :
        lcd.lcd_clear()
        lcd.lcd_display_string("obstical detected", 1)
        lcd.lcd_display_string("Distance :"+ str(myDistance), 2)
       
        md.stop()
        #time.sleep(3)
    elif myDistance>colider or read_ser == list("AC") or read_ser == list("TF") :
        lcd.lcd_clear()
        lcd.lcd_display_string("SAFE DRIVE", 1)
        lcd.lcd_display_string("", 2)
       
        md.forward()     
    elif myDistance<colider or read_ser == list("AC") or read_ser == list("TF") :
        lcd.lcd_clear()
        lcd.lcd_display_string("Vehicle Reverse", 1)
        lcd.lcd_display_string("Distance :"+ str(myDistance), 2)
       
        md.beckward()    
    else :
      
         #Moving Car to Foward Direction 
        md.forward()
        lcd.lcd_clear()
        lcd.lcd_display_string("  Vehicle  ", 1)
        lcd.lcd_display_string("Moving Foward", 2)
   
            