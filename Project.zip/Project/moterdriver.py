import time
import RPi.GPIO as GPIO
import gpiowire

GPIO.setwarnings(False)
GPIO.cleanup()



class MoterDriver:
    gw=gpiowire.GpioWire()
    gpioM1=gw.M1                  
    gpioM2=gw.M2                   
    gpioM3=gw.M3                   
    gpioM4=gw.M4                   

    def __init__(self,mode):

        GPIO.setmode(mode)
        GPIO.setup(self.gpioM1,GPIO.OUT)
        GPIO.setup(self.gpioM2,GPIO.OUT)
        GPIO.setup(self.gpioM3,GPIO.OUT)
        GPIO.setup(self.gpioM4,GPIO.OUT)


    def forward(self):
        GPIO.output(self.gpioM1,GPIO.HIGH)
        GPIO.output(self.gpioM2,GPIO.LOW)
        GPIO.output(self.gpioM3,GPIO.HIGH)
        GPIO.output(self.gpioM4,GPIO.LOW)
        
    def beckword(self):
        GPIO.output(self.gpioM1,GPIO.LOW)
        GPIO.output(self.gpioM2,GPIO.HIGH)
        GPIO.output(self.gpioM3,GPIO.LOW)
        GPIO.output(self.gpioM4,GPIO.HIGH)
        
    def left(self):
        GPIO.output(self.gpioM1,GPIO.HIGH)
        GPIO.output(self.gpioM2,GPIO.LOW)
        GPIO.output(self.gpioM3,GPIO.LOW)
        GPIO.output(self.gpioM4,GPIO.HIGH)
        
    def right(self):
        GPIO.output(self.gpioM1,GPIO.LOW)
        GPIO.output(self.gpioM2,GPIO.HIGH)
        GPIO.output(self.gpioM3,GPIO.HIGH)
        GPIO.output(self.gpioM4,GPIO.LOW)
        

    def stop(self):
        GPIO.output(self.gpioM1,GPIO.LOW)
        GPIO.output(self.gpioM2,GPIO.LOW)
        GPIO.output(self.gpioM3,GPIO.LOW)
        GPIO.output(self.gpioM4,GPIO.LOW)

md = MoterDriver(GPIO.BCM)
md.left()

